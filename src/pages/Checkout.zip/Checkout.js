import React, { useEffect, useState } from "react";
import { useCart } from "react-use-cart";
import Header from "../components/headers/light";
import Footer from "../components/footers/FiveColumnWithInputForm.js";
import AnimationRevealPage from "helpers/AnimationRevealPage.js";
import "react-toastify/dist/ReactToastify.css";
import { useForm } from "react-hook-form";
import tw from "twin.macro";




const Checkout = () => {
  const { handleSubmit, register, getValues } = useForm();
  const { items, emptyCart } = useCart();

  const [formData, setFormData] = useState();

  const [showModal, setShowModal] = useState(false);

  const ModalContainer = tw.div`fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50`;
  const ModalContent = tw.div`bg-white p-8 rounded-lg`;

  const openModal = () => {
    
    setShowModal(true);
  };

  const Container = tw.div`relative bg-gray-200 text-gray-700 -mb-8 -mx-8 px-4 py-8 lg:py-12`;
  const Content = tw.div`max-w-screen-xl mx-auto relative z-10`;
  const CancelButton = tw.button`text-sm mt-4 bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-md ml-5 focus:outline-none cursor-pointer`;
  
  // Todo
  // Panggil state dan juga fungsi createOrder dari ordercontext

  const handleInputChange = data => {
    setFormData(data);
  };

  console.log(formData);

  

  return (
    <AnimationRevealPage>
      <Header className="mb-8" />
      <Container>
        <Content>
          <>
            <div >
              <div className="block p-6 bg-white border border-gray-200 rounded-lg shadow hover:bg-gray-100 dark:bg-gray-100 dark:border-gray-100 mb-5">
                <form onSubmit={handleSubmit(handleInputChange)}>
                  <div className="mb-5">
                    <label for="address" className="block mb-2 text-sm font-medium ">Alamat</label>
                    <input type="text" id="address" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-200 dark:border-gray-600 dark:placeholder-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Masukkan alamat anda disini" {...register("address", {required:true})} />
                  </div>
                  <div className="mb-5">
                    <label for="city" className="block mb-2 text-sm font-medium ">Kota</label>
                    <input type="text" id="city" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-200 dark:border-gray-600 dark:placeholder-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Masukkan kota anda disini" {...register("city", {required:true})} />
                  </div>
                  <div className="mb-5">
                    <label for="postalcode" className="block mb-2 text-sm font-medium ">Kode Pos</label>
                    <input type="number" id="postalcode" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-200 dark:border-gray-600 dark:placeholder-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Masukkan kode pos anda disini" {...register("postalcode", {required:true})} />
                  </div>
                  <div className="mb-10">
                    <label for="country" className="block mb-2 text-sm font-medium ">Negara</label>
                    <input type="text" id="country" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-200 dark:border-gray-600 dark:placeholder-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Masukkan kode pos anda disini" {...register("country", {required:true})} />
                  </div>
                  <button type="submit" onClick={openModal} class="bg-gray-50 border border-gray-900 text-gray-900  hover:text-white hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-10 py-2.5 text-center ">Checkout Now</button>
                </form>
              </div>
            </div>
            <p></p>
          </>
        </Content>
      </Container>
      {showModal && (
        <>
          {formData && (
          <ModalContainer>
            <ModalContent>
              <h2 className="text-2xl font-semibold mb-2">
                Konfirmasi Pesanan
              </h2>
              {items.map((item) => (
                <div>
                  
                  <div className="rounded-xl border-2 border-gray-200 lg:p-2 grid grid-cols-12 mb-4 ">
                    <div key={item.id} className="col-span-3 lg:col-span-2 img box pl-2 ">
                              <img src={item.images[0].url} alt={item.name} className="rounded-lg" style={{width:"100px", height:"100px"}}></img>
                    </div>
                    <div className="col-span-9 lg:col-span-10 detail w-full lg:pl-3">
                      <div className="flex items-center justify-between w-full mb-4">
                        <h5 className="font-manrope font-bold leading-9 text-gray-900">{item.name}</h5>
                      </div>
                      <div class="flex justify-between items-center">
                        <div class="flex items-center gap-4">
                          <p>
                            Quantity : {item.quantity}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                ))}
              <h2 className="text-lg font-semibold mt-4">
              Detail Pengiriman
              </h2>
              <p>Alamat : {formData.address}</p>
              <p>Kota : {formData.city}</p>
              <p>Kode Pos : {formData.postalcode}</p>
              <p>Negara : {formData.country}</p>
              <button className="text-sm cursor-pointer bg-green-500 text-white px-6 py-3 rounded-md hover:bg-green-700">
                Add
              </button>
              <CancelButton onClick={() => setShowModal(false)}>
                Cancel
              </CancelButton>
            </ModalContent>
          </ModalContainer>
          )}
        </>
      )}
      <Footer background="bg-white" />
    </AnimationRevealPage>
  );
};

export default Checkout;
